# Discord Nuke Bot 

## Made by White Code 
A complete code for a discord nuke bot!

Looking for a code for a nuke bot ? This fully open source code is made for your project !

If you need help with this project, to get support faster you can join the help server by just clicking [here](https://discord.gg/break).

I also have a Youtube video of a full tutorial of this to see it click [here](https://youtu.be/Slpnhkdjl7Y).

### 🧰  Set-up

Well, let's start by fixing the code.
Go to the file `main.py`
For the bot to be able to start, please complete the file with your credentials as follows :

- For 𝐁𝐨𝐭_𝐓𝐨𝐤𝐞𝐧

```js
Go to https://discord.com/developers/applications
Then press New application at the top right of the page
After that name the application
Then look to the side and you should see a category named settings
You should see a thing called Bot
Press add bot on the right side
then copy the token.
```

- For 𝐘𝐨𝐮𝐫_𝐍𝐚𝐦𝐞

```js
Put the name you want it to show on the the channel spam
```

- For 𝐒𝐩𝐚𝐦_𝐌𝐞𝐬𝐬𝐚𝐠𝐞

```js
Put the message you want your nuke bot to spam
```
- For 𝐏𝐫𝐞𝐟𝐢𝐱_𝐀𝐫𝐞𝐚

```js
Put the Prefix for your bot
```

- For 𝐁𝐨𝐭_𝐒𝐭𝐚𝐭𝐮𝐬

```js
Put the status you want your bot to show
```

- For 𝐁𝐨𝐭_𝐒𝐭𝐨𝐩

```js
Put your command for bot to stop
```

- For 𝐁𝐨𝐭_𝐍𝐮𝐤𝐞

```js
Put your command for bot to nuke
```

- For 𝐘𝐨𝐮𝐫_𝐔𝐬𝐞𝐫

```js
Put your discord username so it can unban you if you get banned
```

- To start the bot :

## Press run

